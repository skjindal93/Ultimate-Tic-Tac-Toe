-----------------------------------------------------Ultimate Tic Tac Toe-------------------------------------------------------------

Steps to create and test your bot on your own pc
1-  Insert your code in main.py in the space provided at line no 43
2 - Once done, compile the main.py using the command "python main.py"
3 - In step 2 ensure that all the files contained in this zip lie in the same directory.
4 - You will be able to see the status of the game after each move on the console. Use this for debigging purposes.
5 - Once you are done with coding, just upload the getMove() function on the website to your score. A sample code submission has been put up for your reference on the website as well as inside this zip.

--------------------------------------------------------------------------------------------------------------------------------------