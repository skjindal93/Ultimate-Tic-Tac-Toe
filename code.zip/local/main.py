import tictactoe as utic
import game
import argparse
import argparse
from copy import deepcopy
import random


parser = argparse.ArgumentParser()
parser.add_argument("--p2",help="Select the first player as AP for your AI player, RP for a random player, and MP for a manual player. Default is AI.")
parser.add_argument("--p1", help="Optional selection of Player 1. Default is RP")
args = parser.parse_args()


# Returns true if Player has won the smaller Tic-Tac-Toe board at I,J.
def ifSmallWin(State,I,J,Player):
	def orfunc(x,y):	return x or y
	def andfunc(x,y):	return x and y
	horizontalwin = reduce(orfunc, [True if reduce(andfunc,[True if State[0][I][J][i][j]==Player else False for j in xrange(3)]) else False for i in xrange(3)])
	verticalwin = reduce(orfunc, [True if reduce(andfunc,[True if State[0][I][J][j][i]==Player else False for j in xrange(3)]) else False for i in xrange(3)])
	diagonal1win = reduce(andfunc, [ True if State[0][I][J][i][i]==Player else False for i in xrange(3)])
	diagonal2win = reduce(andfunc, [ True if State[0][I][J][2-i][i]==Player else False for i in xrange(3)])
	return horizontalwin or diagonal1win or verticalwin or diagonal2win


# Returns true if there exists empty positions on the smaller board at I,J.
def checkEmpty(State,I,J):
	return reduce((lambda x,y : x or y), [True if (State[0][I][J][i][j]==None) else False for i in xrange(3) for j in xrange(3)])


class AIPlayer(game.Player):
	def __init__(self,id):
		super(AIPlayer, self).__init__(id)


	# Code your solution here. Your function should return a tuple I,J,i,j. 
	# Here, I,J are the row and column number of the bigger Tic Tac Toe board and i,j of the smaller board at position I,J.
	# State[0][I][J][i][j] stores the Player at that board position if any, else None.
	# State[1] is a 2-tuple (I,J) indicating the board position the last player sent the current player to.
	# @timeout(timeP2)
	def getMove(self,State,PlayerList=[]):
		I,J = State[1]
		if not reduce(lambda x,y : x or y, [True if ifSmallWin(State,I,J,player) else False for player in PlayerList]) and checkEmpty(State,I,J):
			while True:
				i,j  = random.randint(0,2), random.randint(0,2)
				if State[0][I][J][i][j] == None:
					return I,J,i,j
		else:
			for x,y in [(I,J) for I in xrange(3) for J in xrange(3)]:
				if not reduce(lambda x,y : x or y, [True if ifSmallWin(State,x,y,player) else False for player in PlayerList]) and checkEmpty(State,x,y):
					while True:
						i,j  = random.randint(0,2), random.randint(0,2)
						if State[0][x][y][i][j] == None:
							return x,y,i,j
		pass


if __name__ == '__main__' :

	if not args.p1 or args.p1 == 'AI':
		P1 = AIPlayer(1)
	elif args.p1 == 'RP':
		P1 = utic.RandomPlayer(1)
	elif args.p1 == 'MP':
		P1 = utic.ManualPlayer(1)
	else:
		raise game.Error("Please select a valid player.")

	if not args.p2 or args.p2 == 'RP':
		P2 = utic.RandomPlayer(2)
	elif args.p2 == 'AP':
		P2 = AIPlayer(2)
	elif args.p2 == 'MP':
		P2 = utic.ManualPlayer(2)
	else:
		raise game.Error("Please select a valid player.")


	State = utic.State([P1,P2],2)
	# Change the third argument to True to print the gamestate after every move.
	# Change the fourth argument to True to wait for keyboard input to move to the next state.
	# Press enter to advance the game by two moves.
	Game = utic.TicTacToeGame(State, [P1,P2],True,False)

	Game.run()
